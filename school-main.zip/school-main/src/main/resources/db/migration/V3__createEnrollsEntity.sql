CREATE TABLE Enrolls (
    user_id VARCHAR(20),
    course_id VARCHAR(100),
    data TIMESTAMP NOT NULL
);