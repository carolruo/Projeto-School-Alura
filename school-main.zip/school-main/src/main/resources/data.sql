insert into User (username, email, role) values ('alex', 'alex@email.com', 'INSTRUCTOR');
insert into User (username, email, role) values ('ana', 'ana@email.com', 'STUDENT');

insert into Course (code, name, description) values ('java-1', 'Java OO', 'Java and Object Orientation: Encapsulation, Inheritance and Polymorphism.');
insert into Course (code, name, description) values ('java-2', 'Java Collections', 'Java Collections: Lists, Sets, Maps and more.');
