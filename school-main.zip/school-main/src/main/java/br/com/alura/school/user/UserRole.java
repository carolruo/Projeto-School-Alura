package br.com.alura.school.user;

public enum UserRole {
    STUDENT,
    INSTRUCTOR,
    DEV;
}
