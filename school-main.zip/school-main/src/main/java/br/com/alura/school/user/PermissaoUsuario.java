package br.com.alura.school.user;

public enum PermissaoUsuario {

    ALUNO,
    INSTRUTOR;
}
